﻿using Azure.Storage.Blobs;
using FileManagement.Service.Interface;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagement.Service.Service
{
    public class BlobService : IBlobService
    {
        private readonly BlobContainerClient _container;

        public BlobService(IConfiguration config)
        {
            var connectionString = config["AzureBlob:ConnectionString"];
            var containerName = config["AzureBlob:ContainerName"];
            _container = new BlobContainerClient(connectionString, containerName);
            _container.CreateIfNotExists();
        }

        public async Task<string> UploadAsync(Stream stream, string fileName, string userId)
        {
            string uniqueFileName = $"{Guid.NewGuid()}-{fileName}";
            string blobPath = $"user-{userId}/{uniqueFileName}";
            var blobClient = _container.GetBlobClient(blobPath);

            await blobClient.UploadAsync(stream, overwrite: true);
            return blobPath;
        }

        public async Task<MemoryStream> DownloadAsync(string blobPath)
        {
            var blobClient = _container.GetBlobClient(blobPath);
            var ms = new MemoryStream();
            await blobClient.DownloadToAsync(ms);
            ms.Position = 0;
            return ms;
        }

        public async Task<bool> DeleteAsync(string blobPath)
        {
            var blobClient = _container.GetBlobClient(blobPath);
            return await blobClient.DeleteIfExistsAsync();
        }
    }
}