﻿using FileManagement.API.Model;
using FileManagement.DAL;
using FileManagement.Service.Interface;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace FileManagement.Service.Service
{
    public class FileService : IFileService
    {
        private readonly IBlobService _blobService;

        private readonly FileManagementDbContext _dbContext;

        public FileService(IBlobService blobService, FileManagementDbContext dbContext)
        {
            _blobService = blobService;
            _dbContext = dbContext;
        }

        public async Task<List<UserFile>> GetFiles(string userId)
        {
            var files = await _dbContext.UserFiles
                .Where(f => f.UserId == userId)
                .ToListAsync();

            return files;
        }

        public async Task<int> UploadAsync(Stream fileStream, string fileName, string userId)
        {
            var blobPath = await _blobService.UploadAsync(fileStream, fileName, userId);

            var userFile = new UserFile
            {
                UserId = userId,
                FileName = fileName,
                BlobPath = blobPath,
                Size = fileStream.Length,
                UploadedAt = DateTime.UtcNow
            };

            _dbContext.UserFiles.Add(userFile);
            await _dbContext.SaveChangesAsync();

            return userFile.Id;
        }

        public async Task<MemoryStream> DownloadAsync(int fileId, string userId)
        {
            var file = await _dbContext.UserFiles.FirstOrDefaultAsync(f => f.Id == fileId);
            MemoryStream ms = new MemoryStream();

            if (file != null && file.UserId == userId)
                ms = await _blobService.DownloadAsync(file.BlobPath);

            return ms;
        }


        public async Task<bool> DeleteAsync(int fileId, string userId)
        {
            var file = await _dbContext.UserFiles.FirstOrDefaultAsync(f => f.Id == fileId);
            bool isDeleted = false;
            if (file != null && file.UserId == userId)
                isDeleted = await _blobService.DeleteAsync(file.BlobPath);

            return isDeleted;
        }
    }
}
