﻿using FileManagement.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagement.Service.Interface
{
    public interface IFileService
    {
        Task<List<UserFile>> GetFiles(string userId);
        Task<int> UploadAsync(Stream fileStream, string fileName, string userId);
        Task<MemoryStream> DownloadAsync(int fileId, string userId);
        Task<bool> DeleteAsync(int fileId, string userId);
    }
}
