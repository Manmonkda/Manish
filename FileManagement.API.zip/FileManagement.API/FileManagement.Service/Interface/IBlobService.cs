﻿namespace FileManagement.Service.Interface
{
    public interface IBlobService
    {
        Task<string> UploadAsync(Stream fileStream, string fileName, string userId);
        Task<MemoryStream> DownloadAsync(string blobPath);
        Task<bool> DeleteAsync(string blobPath);
    }
}