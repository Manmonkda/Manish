﻿namespace FileManagement.API.Model
{
    public class UserFile
    {
        public int Id { get; set; }
        public string UserId { get; set; }     // owner
        public string FileName { get; set; }   // original name
        public string BlobPath { get; set; }   // azure location
        public long Size { get; set; }
        public DateTime UploadedAt { get; set; }
    }
}