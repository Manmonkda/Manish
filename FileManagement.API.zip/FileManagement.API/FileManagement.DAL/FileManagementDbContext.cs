﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using FileManagement.API.Model;
using Microsoft.EntityFrameworkCore;

namespace FileManagement.DAL
{
    public class FileManagementDbContext : DbContext
    {
        public FileManagementDbContext(DbContextOptions<FileManagementDbContext> options)
            : base(options)
        {
        }

        public DbSet<UserFile> UserFiles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<UserFile>(entity =>
            {
                entity.ToTable("UserFiles");

                entity.HasKey(f => f.Id);

                entity.Property(f => f.UserId)
                    .IsRequired();

                entity.Property(f => f.FileName)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(f => f.BlobPath)
                    .IsRequired();

                entity.Property(f => f.Size)
                    .IsRequired();

                entity.Property(f => f.UploadedAt)
                    .HasDefaultValueSql("GETUTCDATE()");
            });
        }
    }
}
