﻿using FileManagement.DAL;
using FileManagement.Service.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace FileManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class FilesController : ControllerBase
    {
        private ILogger<FilesController> _logger;
        private IFileService _fileService;

        public FilesController(ILogger<FilesController> logger, IFileService fileService)
        {
            _logger = logger;
            _fileService = fileService;
        }

        [HttpGet]
        public async Task<IActionResult> GetFiles()
        {
            _logger.LogInformation("GetFiles method started");
            string userId = User.FindFirst(ClaimTypes.NameIdentifier).Value;

            var files = await _fileService.GetFiles(userId);

            _logger.LogInformation("GetFiles method End");

            return Ok(files);
        }

        [HttpPost("upload")]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("File is required.");

            string userId = User.FindFirst(ClaimTypes.NameIdentifier).Value;

            var fileId = await _fileService.UploadAsync(file.OpenReadStream(), file.FileName, userId);

            return Created();
        }

        [HttpGet("{id}/download")]
        public async Task<IActionResult> Download(int id)
        {
            string userId = User.FindFirst(ClaimTypes.NameIdentifier).Value;

            var fileStream = await _fileService.DownloadAsync(id, userId);

            return File(fileStream, "application/octet-stream");
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            string userId = User.FindFirst(ClaimTypes.NameIdentifier).Value;

            await _fileService.DeleteAsync(id, userId);

            return NoContent();
        }
    }
}